import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { toolId, systemPrompt, userInput } = await req.json();

    const openAIKey = Deno.env.get("OPENAI_API_KEY");

    if (!openAIKey) {
      // Return a demo response when OpenAI key is not configured
      const demoResponses: Record<string, string> = {
        "content-writer": `# محتوى احترافي

بناءً على طلبك: "${userInput}"

## المقدمة
هذا محتوى تجريبي تم إنشاؤه بواسطة AI Hub Arabia. لتفعيل الذكاء الاصطناعي الكامل، يرجى إضافة مفتاح OpenAI API.

## المحتوى الرئيسي
- نقطة رئيسية أولى تتعلق بالموضوع المطلوب
- نقطة ثانية تعزز الفكرة الأساسية
- نقطة ثالثة تقدم قيمة إضافية للقارئ

## الخاتمة
هذا مثال على جودة المحتوى الذي يمكن لـ AI Hub Arabia إنتاجه بسرعة واحترافية.`,
        "email-writer": `الموضوع: متابعة طلبكم الكريم

السادة المحترمون،

تحية طيبة وبعد،

بناءً على ${userInput}

نشكركم على تواصلكم الكريم معنا، ونود إحاطتكم علماً بأننا تلقينا رسالتكم وسيتم التعامل معها بالأولوية القصوى.

سنعود إليكم قريباً بالرد المناسب.

وتقبلوا فائق الاحترام والتقدير،
[اسمك]`,
        default: `شكراً على استخدام ${toolId}.

بناءً على المدخل: "${userInput}"

هذه نتيجة تجريبية من AI Hub Arabia. النظام يعمل بشكل صحيح. لتفعيل نتائج الذكاء الاصطناعي الحقيقية، يرجى إضافة مفتاح OpenAI API في إعدادات المشروع.

المنصة تدعم:
• GPT-4 لأفضل النتائج
• معالجة اللغة العربية بشكل كامل
• نتائج احترافية في ثوانٍ`
      };

      const result = demoResponses[toolId] || demoResponses.default;

      return new Response(JSON.stringify({ result }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openAIKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userInput },
        ],
        max_tokens: 2000,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error?.message || "OpenAI API error");
    }

    const data = await response.json();
    const result = data.choices?.[0]?.message?.content || "";

    return new Response(JSON.stringify({ result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
