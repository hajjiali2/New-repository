export async function runOpenRouterTool({
  systemPrompt,
  userInput,
}: {
  systemPrompt: string;
  userInput: string;
}) {
  const apiKey = import.meta.env.VITE_OPENROUTER_API_KEY;

  if (!apiKey) {
    throw new Error('مفتاح OpenRouter غير موجود. أضف VITE_OPENROUTER_API_KEY داخل ملف .env ثم أعد تشغيل المشروع.');
  }

  const response = await fetch('https://openrouter.ai/api/v1/chat/completions', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': window.location.origin,
      'X-Title': 'AI Hub Arabia',
    },
    body: JSON.stringify({
      model: 'deepseek/deepseek-chat-v3-0324:free',
      messages: [
        {
          role: 'system',
          content: systemPrompt || 'أنت مساعد ذكاء اصطناعي عربي محترف. أجب باللغة العربية بشكل واضح ومنظم.',
        },
        {
          role: 'user',
          content: userInput,
        },
      ],
      temperature: 0.7,
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data?.error?.message || 'فشل الاتصال بخدمة الذكاء الاصطناعي.');
  }

  return data?.choices?.[0]?.message?.content || 'لم يتم توليد نتيجة.';
}
