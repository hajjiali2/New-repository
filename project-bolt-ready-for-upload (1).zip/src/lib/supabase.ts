import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string;
          email: string;
          avatar_url: string;
          is_admin: boolean;
          credits: number;
          plan: string;
          company: string;
          phone: string;
          language: string;
          dark_mode: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: Partial<Database['public']['Tables']['profiles']['Row']> & { id: string };
        Update: Partial<Database['public']['Tables']['profiles']['Row']>;
      };
      tool_usage: {
        Row: {
          id: string;
          user_id: string;
          tool_id: string;
          tool_name: string;
          credits_used: number;
          status: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['tool_usage']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['tool_usage']['Row']>;
      };
      tool_results: {
        Row: {
          id: string;
          user_id: string;
          tool_id: string;
          tool_name: string;
          input_data: Record<string, unknown>;
          output_text: string;
          is_saved: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['tool_results']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['tool_results']['Row']>;
      };
      api_keys: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          key_prefix: string;
          key_hash: string;
          last_used_at: string | null;
          is_active: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['api_keys']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['api_keys']['Row']>;
      };
      leads: {
        Row: {
          id: string;
          name: string;
          email: string;
          company: string;
          phone: string;
          message: string;
          source: string;
          status: string;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['leads']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['leads']['Row']>;
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          title: string;
          message: string;
          type: string;
          is_read: boolean;
          created_at: string;
        };
        Insert: Omit<Database['public']['Tables']['notifications']['Row'], 'id' | 'created_at'>;
        Update: Partial<Database['public']['Tables']['notifications']['Row']>;
      };
    };
  };
};
