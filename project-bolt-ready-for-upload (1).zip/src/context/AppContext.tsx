import { createContext, useContext, useState, ReactNode } from 'react';

interface AppContextType {
  lang: 'ar' | 'en';
  setLang: (lang: 'ar' | 'en') => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
  chatOpen: boolean;
  setChatOpen: (open: boolean) => void;
  t: (ar: string, en: string) => string;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<'ar' | 'en'>('ar');
  const [darkMode, setDarkMode] = useState(true);
  const [chatOpen, setChatOpen] = useState(false);

  const setLang = (l: 'ar' | 'en') => {
    setLangState(l);
    document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = l;
  };

  const toggleDarkMode = () => {
    setDarkMode(d => {
      const next = !d;
      if (next) document.documentElement.classList.add('dark');
      else document.documentElement.classList.remove('dark');
      return next;
    });
  };

  const t = (ar: string, en: string) => lang === 'ar' ? ar : en;

  return (
    <AppContext.Provider value={{ lang, setLang, darkMode, toggleDarkMode, chatOpen, setChatOpen, t }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
