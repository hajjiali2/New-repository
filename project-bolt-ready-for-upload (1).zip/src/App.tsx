import { useState } from 'react';
import { AuthProvider } from './context/AuthContext';
import { supabase } from './lib/supabase';
import { AppProvider } from './context/AppContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import ChatWidget from './components/ChatWidget';
import HomePage from './pages/HomePage';
import ToolsPage from './pages/ToolsPage';
import IndividualsPage from './pages/IndividualsPage';
import ToolDetailPage from './pages/ToolDetailPage';
import AuthPage from './pages/AuthPage';
import DashboardPage from './pages/DashboardPage';
import PricingPage from './pages/PricingPage';
import AccountPage from './pages/AccountPage';
import AdminPage from './pages/AdminPage';

type Page =
  | 'home' | 'tools' | 'individuals' | 'tool' | 'pricing' | 'enterprise' | 'contact'
  | 'login' | 'register' | 'dashboard' | 'account' | 'settings'
  | 'api-keys' | 'notifications' | 'admin' | 'about' | 'blog';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [toolId, setToolId] = useState<string>('');

  const handleNavigate = (page: string, id?: string) => {
    setCurrentPage(page as Page);
    if (id) setToolId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const showNavbar = !['login', 'register'].includes(currentPage);
  const showFooter = !['login', 'register', 'dashboard', 'account', 'admin', 'api-keys', 'notifications', 'settings'].includes(currentPage);

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <HomePage onNavigate={handleNavigate} />;
      case 'tools': return <ToolsPage onNavigate={handleNavigate} />;
      case 'individuals': return <IndividualsPage onNavigate={handleNavigate} />;
      case 'tool': return <ToolDetailPage toolId={toolId} onNavigate={handleNavigate} />;
      case 'pricing': return <PricingPage onNavigate={handleNavigate} />;
      case 'login': return <AuthPage mode="login" onNavigate={handleNavigate} />;
      case 'register': return <AuthPage mode="register" onNavigate={handleNavigate} />;
      case 'dashboard': return <DashboardPage onNavigate={handleNavigate} />;
      case 'account':
      case 'api-keys':
      case 'notifications':
      case 'settings':
        return <AccountPage onNavigate={handleNavigate} />;
      case 'admin': return <AdminPage onNavigate={handleNavigate} />;
      case 'enterprise':
      case 'contact':
        return <ContactPage onNavigate={handleNavigate} />;
      default: return <HomePage onNavigate={handleNavigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#060f33] text-white font-arabic">
      {showNavbar && <Navbar onNavigate={handleNavigate} currentPage={currentPage} />}
      <main>{renderPage()}</main>
      {showFooter && <Footer onNavigate={handleNavigate} />}
      <ChatWidget />
    </div>
  );
}

// Inline contact/enterprise page
function ContactPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const [form, setForm] = useState({ name: '', email: '', company: '', phone: '', message: '' });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await supabase.from('leads').insert({ ...form, source: 'contact_page', status: 'new' });
    } catch {}
    setLoading(false);
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-green-400 text-2xl">✓</span>
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">تم الإرسال!</h2>
          <p className="text-gray-400 mb-6">سنتواصل معك خلال 24 ساعة</p>
          <button onClick={() => onNavigate('home')} className="px-6 py-2 bg-orange-500 text-white rounded-xl">
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-2xl mx-auto px-4 py-16">
        <h1 className="text-4xl font-black text-white mb-3 text-center">تواصل معنا</h1>
        <p className="text-gray-400 text-center mb-10">نحن هنا للإجابة على جميع استفساراتك</p>
        <form onSubmit={handleSubmit} className="space-y-4 bg-white/5 border border-white/10 rounded-2xl p-8">
          {[
            { key: 'name', label: 'الاسم', type: 'text', required: true },
            { key: 'email', label: 'البريد الإلكتروني', type: 'email', required: true },
            { key: 'company', label: 'الشركة', type: 'text', required: false },
            { key: 'phone', label: 'الهاتف', type: 'tel', required: false },
          ].map(field => (
            <div key={field.key}>
              <label className="text-sm text-gray-400 mb-1.5 block">{field.label}</label>
              <input
                type={field.type}
                required={field.required}
                value={form[field.key as keyof typeof form]}
                onChange={e => setForm(p => ({ ...p, [field.key]: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500/50"
              />
            </div>
          ))}
          <div>
            <label className="text-sm text-gray-400 mb-1.5 block">الرسالة</label>
            <textarea
              rows={4}
              value={form.message}
              onChange={e => setForm(p => ({ ...p, message: e.target.value }))}
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500/50 resize-none"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white font-semibold rounded-xl hover:from-orange-600 hover:to-orange-700 transition-all"
          >
            {loading ? 'جاري الإرسال...' : 'إرسال'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </AppProvider>
  );
}
