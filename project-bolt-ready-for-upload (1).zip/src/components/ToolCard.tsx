import { AITool } from '../data/tools';
import { useApp } from '../context/AppContext';
import * as Icons from 'lucide-react';
import { Zap } from 'lucide-react';

interface ToolCardProps {
  tool: AITool;
  onNavigate: (page: string, toolId?: string) => void;
}

export default function ToolCard({ tool, onNavigate }: ToolCardProps) {
  const { t } = useApp();
  const IconComponent = (Icons as unknown as Record<string, React.ComponentType<{ className?: string }>>)[tool.icon] || Zap;

  return (
    <div
      onClick={() => onNavigate('tool', tool.id)}
      className="group relative bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 hover:border-orange-500/30 rounded-2xl p-5 cursor-pointer transition-all duration-300 hover:shadow-xl hover:shadow-orange-500/10 hover:-translate-y-0.5 overflow-hidden"
    >
      {/* Glow effect */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-orange-500/5 to-transparent rounded-2xl" />
      </div>

      {/* Badges */}
      <div className="flex items-center gap-1.5 absolute top-3 inset-inline-end-3">
        {tool.isNew && (
          <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-full text-xs font-medium">
            {t('جديد', 'New')}
          </span>
        )}
        {tool.isPopular && (
          <span className="px-2 py-0.5 bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-full text-xs font-medium">
            {t('الأكثر استخداماً', 'Popular')}
          </span>
        )}
      </div>

      {/* Icon */}
      <div
        className="w-12 h-12 rounded-2xl flex items-center justify-center mb-4 shadow-lg"
        style={{ background: `linear-gradient(135deg, ${tool.color}33, ${tool.color}22)`, border: `1px solid ${tool.color}33` }}
      >
        <IconComponent className="w-5.5 h-5.5" style={{ color: tool.color }} />
      </div>

      {/* Content */}
      <h3 className="text-white font-semibold mb-1.5 text-base">{t(tool.nameAr, tool.nameEn)}</h3>
      <p className="text-gray-400 text-sm leading-relaxed line-clamp-2">{t(tool.descriptionAr, tool.descriptionEn)}</p>

      {/* Footer */}
      <div className="flex items-center justify-between mt-4 pt-4 border-t border-white/5">
        <span className="px-2.5 py-1 bg-white/5 text-gray-400 rounded-lg text-xs">
          {t(tool.categoryAr, tool.category)}
        </span>
        <div className="flex items-center gap-1 text-xs text-gray-500">
          <Zap className="w-3 h-3 text-orange-400" />
          <span>{tool.credits} {t('رصيد', 'credits')}</span>
        </div>
      </div>
    </div>
  );
}
