import { Brain, Twitter, Linkedin, Instagram, Mail, Phone, MapPin, ArrowUpRight } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export default function Footer({ onNavigate }: FooterProps) {
  const { t } = useApp();

  const links = {
    product: [
      { label: t('الأدوات', 'Tools'), page: 'tools' },
      { label: t('الأسعار', 'Pricing'), page: 'pricing' },
      { label: t('الشركات', 'Enterprise'), page: 'enterprise' },
      { label: t('الـ API', 'API'), page: 'api' },
    ],
    company: [
      { label: t('من نحن', 'About'), page: 'about' },
      { label: t('المدونة', 'Blog'), page: 'blog' },
      { label: t('الوظائف', 'Careers'), page: 'careers' },
      { label: t('اتصل بنا', 'Contact'), page: 'contact' },
    ],
    legal: [
      { label: t('سياسة الخصوصية', 'Privacy Policy'), page: 'privacy' },
      { label: t('شروط الاستخدام', 'Terms of Service'), page: 'terms' },
      { label: t('سياسة الكوكيز', 'Cookie Policy'), page: 'cookies' },
    ],
  };

  return (
    <footer className="bg-[#030818] border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <button onClick={() => onNavigate('home')} className="flex items-center gap-2.5 mb-5">
              <div className="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/30">
                <Brain className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg font-bold text-white">
                AI Hub <span className="text-orange-400">Arabia</span>
              </span>
            </button>
            <p className="text-gray-400 text-sm leading-relaxed mb-6 max-w-xs">
              {t(
                'منصة الذكاء الاصطناعي الأولى عربياً للشركات ورواد الأعمال. نقدم أدوات ذكاء اصطناعي متقدمة تساعدك على تسريع أعمالك.',
                'The first Arabic AI platform for businesses and entrepreneurs. We provide advanced AI tools to accelerate your business.'
              )}
            </p>
            <div className="flex items-center gap-3">
              {[
                { icon: Twitter, href: '#' },
                { icon: Linkedin, href: '#' },
                { icon: Instagram, href: '#' },
              ].map(({ icon: Icon, href }, i) => (
                <a
                  key={i}
                  href={href}
                  className="w-9 h-9 bg-white/5 hover:bg-orange-500/20 border border-white/10 hover:border-orange-500/30 rounded-xl flex items-center justify-center text-gray-400 hover:text-orange-400 transition-all"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          {[
            { title: t('المنتج', 'Product'), items: links.product },
            { title: t('الشركة', 'Company'), items: links.company },
            { title: t('القانوني', 'Legal'), items: links.legal },
          ].map((section, i) => (
            <div key={i}>
              <h3 className="text-white font-semibold mb-4 text-sm">{section.title}</h3>
              <ul className="space-y-3">
                {section.items.map((item, j) => (
                  <li key={j}>
                    <button
                      onClick={() => onNavigate(item.page)}
                      className="text-gray-400 hover:text-white text-sm transition-colors flex items-center gap-1 group"
                    >
                      {item.label}
                      <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Contact & Bottom */}
        <div className="mt-12 pt-8 border-t border-white/5">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex flex-wrap items-center gap-6 text-sm text-gray-500">
              {[
                { icon: Mail, text: 'hello@aihub.arabia' },
                { icon: Phone, text: '+966 50 000 0000' },
                { icon: MapPin, text: t('الرياض، المملكة العربية السعودية', 'Riyadh, Saudi Arabia') },
              ].map(({ icon: Icon, text }, i) => (
                <span key={i} className="flex items-center gap-1.5">
                  <Icon className="w-3.5 h-3.5 text-orange-500/60" />
                  {text}
                </span>
              ))}
            </div>
            <p className="text-gray-600 text-sm">
              {t('© 2024 AI Hub Arabia. جميع الحقوق محفوظة.', '© 2024 AI Hub Arabia. All rights reserved.')}
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
