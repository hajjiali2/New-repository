import { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Bot, User } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  time: string;
}

export default function ChatWidget() {
  const { chatOpen, setChatOpen, t } = useApp();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      text: t(
        'مرحباً! أنا مساعد AI Hub Arabia. كيف يمكنني مساعدتك اليوم؟',
        'Hello! I\'m the AI Hub Arabia assistant. How can I help you today?'
      ),
      time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typing]);

  const sendMessage = () => {
    if (!input.trim()) return;
    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setTyping(true);

    setTimeout(() => {
      const replies = [
        t('يمكنني مساعدتك في اختيار الأداة المناسبة لاحتياجاتك. ما هو مجال عملك؟', 'I can help you choose the right tool for your needs. What is your field of work?'),
        t('لدينا أكثر من 15 أداة ذكاء اصطناعي. هل تريد معرفة المزيد عن أي منها؟', 'We have more than 15 AI tools. Would you like to know more about any of them?'),
        t('للاشتراك في الخطة الاحترافية تواصل معنا أو اضغط على زر الأسعار.', 'To subscribe to the professional plan, contact us or click the Pricing button.'),
      ];
      const reply: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        text: replies[Math.floor(Math.random() * replies.length)],
        time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, reply]);
      setTyping(false);
    }, 1500);
  };

  return (
    <>
      {/* Toggle Button */}
      <button
        onClick={() => setChatOpen(!chatOpen)}
        className="fixed bottom-6 z-50 w-14 h-14 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl shadow-2xl shadow-orange-500/40 flex items-center justify-center hover:scale-110 transition-transform animate-glow"
        style={{ insetInlineEnd: '1.5rem' }}
      >
        {chatOpen ? <X className="w-6 h-6 text-white" /> : <MessageCircle className="w-6 h-6 text-white" />}
        {!chatOpen && (
          <span className="absolute -top-1 w-3 h-3 bg-green-400 rounded-full border-2 border-[#060f33]" style={{ insetInlineEnd: '-0.25rem' }} />
        )}
      </button>

      {/* Chat Panel */}
      {chatOpen && (
        <div
          className="fixed bottom-24 z-50 w-80 sm:w-96 bg-[#0d1b4b] border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-slide-up flex flex-col"
          style={{ insetInlineEnd: '1.5rem', maxHeight: '480px' }}
        >
          {/* Header */}
          <div className="flex items-center gap-3 px-4 py-3 bg-gradient-to-r from-orange-500 to-orange-600">
            <div className="w-8 h-8 bg-white/20 rounded-xl flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold text-white">{t('مساعد AI Hub', 'AI Hub Assistant')}</p>
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
                <p className="text-xs text-orange-100">{t('متاح الآن', 'Online now')}</p>
              </div>
            </div>
            <button onClick={() => setChatOpen(false)} className="ms-auto text-white/70 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 min-h-0" style={{ maxHeight: '320px' }}>
            {messages.map(msg => (
              <div key={msg.id} className={`flex items-start gap-2 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                <div className={`w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 ${
                  msg.role === 'assistant' ? 'bg-orange-500/20' : 'bg-blue-500/20'
                }`}>
                  {msg.role === 'assistant' ? <Bot className="w-3.5 h-3.5 text-orange-400" /> : <User className="w-3.5 h-3.5 text-blue-400" />}
                </div>
                <div className={`max-w-[75%] ${msg.role === 'user' ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                  <div className={`px-3 py-2 rounded-2xl text-sm ${
                    msg.role === 'assistant'
                      ? 'bg-white/5 text-gray-200 rounded-ss-none'
                      : 'bg-orange-500 text-white rounded-se-none'
                  }`}>
                    {msg.text}
                  </div>
                  <span className="text-xs text-gray-600">{msg.time}</span>
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-orange-500/20 flex items-center justify-center">
                  <Bot className="w-3.5 h-3.5 text-orange-400" />
                </div>
                <div className="px-3 py-2 bg-white/5 rounded-2xl rounded-ss-none flex gap-1">
                  {[0, 1, 2].map(i => (
                    <span key={i} className="w-1.5 h-1.5 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
                  ))}
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t border-white/10">
            <div className="flex items-center gap-2 bg-white/5 rounded-xl px-3 py-2">
              <input
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && sendMessage()}
                placeholder={t('اكتب رسالتك...', 'Type your message...')}
                className="flex-1 bg-transparent text-sm text-white placeholder-gray-500 outline-none"
              />
              <button
                onClick={sendMessage}
                disabled={!input.trim()}
                className="w-7 h-7 bg-orange-500 hover:bg-orange-600 disabled:opacity-40 rounded-lg flex items-center justify-center transition-all flex-shrink-0"
              >
                <Send className="w-3.5 h-3.5 text-white" />
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
