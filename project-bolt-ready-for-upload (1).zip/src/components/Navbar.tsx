import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { Brain, Menu, X, Bell, ChevronDown, LogOut, User, LayoutDashboard, Settings, Sun, Moon, Globe } from 'lucide-react';

interface NavbarProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export default function Navbar({ onNavigate, currentPage }: NavbarProps) {
  const { user, profile, signOut } = useAuth();
  const { lang, setLang, darkMode, toggleDarkMode, t } = useApp();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  const navLinks = [
    { label: t('للشركات', 'For Business'), page: 'tools' },
    { label: t('للأفراد', 'For Individuals'), page: 'individuals' },
    { label: t('الأسعار', 'Pricing'), page: 'pricing' },
    { label: t('الشركات', 'Enterprise'), page: 'enterprise' },
  ];

  return (
    <nav className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-[#060f33]/95 backdrop-blur-xl border-b border-white/10 shadow-2xl' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-18">
          {/* Logo */}
          <button onClick={() => onNavigate('home')} className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/30 group-hover:scale-105 transition-transform">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold text-white">
              AI Hub <span className="text-orange-400">Arabia</span>
            </span>
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <button
                key={link.page}
                onClick={() => onNavigate(link.page)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentPage === link.page
                    ? 'text-orange-400 bg-orange-500/10'
                    : 'text-gray-300 hover:text-white hover:bg-white/5'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Language Toggle */}
            <button
              onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all text-sm font-medium"
            >
              <Globe className="w-4 h-4" />
              {lang === 'ar' ? 'EN' : 'عربي'}
            </button>

            {/* Dark Mode */}
            <button
              onClick={toggleDarkMode}
              className="hidden md:flex p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all"
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {user ? (
              <>
                {/* Notifications */}
                <button
                  onClick={() => onNavigate('dashboard')}
                  className="relative p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5 transition-all"
                >
                  <Bell className="w-4 h-4" />
                  <span className="absolute top-1 right-1 w-2 h-2 bg-orange-500 rounded-full" />
                </button>

                {/* Profile Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setProfileOpen(!profileOpen)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all border border-white/10"
                  >
                    <div className="w-6 h-6 bg-gradient-to-br from-orange-400 to-orange-600 rounded-lg flex items-center justify-center text-xs font-bold text-white">
                      {profile?.full_name?.charAt(0) || user.email?.charAt(0)?.toUpperCase()}
                    </div>
                    <span className="text-sm text-white font-medium hidden sm:block max-w-[100px] truncate">
                      {profile?.full_name || user.email?.split('@')[0]}
                    </span>
                    <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform ${profileOpen ? 'rotate-180' : ''}`} />
                  </button>

                  {profileOpen && (
                    <div className="absolute top-full mt-2 w-56 bg-[#0d1b4b] border border-white/10 rounded-2xl shadow-2xl overflow-hidden" style={{ insetInlineEnd: 0 }}>
                      <div className="px-4 py-3 border-b border-white/10">
                        <p className="text-sm font-medium text-white truncate">{profile?.full_name}</p>
                        <p className="text-xs text-gray-400 truncate">{user.email}</p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="px-2 py-0.5 bg-orange-500/20 text-orange-400 rounded-full text-xs font-medium capitalize">
                            {profile?.plan || 'free'}
                          </span>
                          <span className="text-xs text-gray-400">{profile?.credits} {t('رصيد', 'credits')}</span>
                        </div>
                      </div>
                      <div className="py-1">
                        {[
                          { icon: LayoutDashboard, label: t('لوحة التحكم', 'Dashboard'), page: 'dashboard' },
                          { icon: User, label: t('حسابي', 'My Account'), page: 'account' },
                          { icon: Settings, label: t('الإعدادات', 'Settings'), page: 'settings' },
                          ...(profile?.is_admin ? [{ icon: Settings, label: t('الإدارة', 'Admin'), page: 'admin' }] : []),
                        ].map(item => (
                          <button
                            key={item.page}
                            onClick={() => { onNavigate(item.page); setProfileOpen(false); }}
                            className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-gray-300 hover:text-white hover:bg-white/5 transition-all"
                          >
                            <item.icon className="w-4 h-4 text-gray-400" />
                            {item.label}
                          </button>
                        ))}
                        <button
                          onClick={() => { signOut(); setProfileOpen(false); }}
                          className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-red-400 hover:text-red-300 hover:bg-red-500/5 transition-all border-t border-white/10 mt-1"
                        >
                          <LogOut className="w-4 h-4" />
                          {t('تسجيل الخروج', 'Sign Out')}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onNavigate('login')}
                  className="hidden sm:flex px-4 py-2 text-sm font-medium text-gray-300 hover:text-white transition-colors"
                >
                  {t('دخول', 'Login')}
                </button>
                <button
                  onClick={() => onNavigate('register')}
                  className="px-4 py-2 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white text-sm font-semibold rounded-xl transition-all shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 hover:scale-105"
                >
                  {t('ابدأ مجاناً', 'Start Free')}
                </button>
              </div>
            )}

            {/* Mobile Menu */}
            <button
              onClick={() => setMenuOpen(!menuOpen)}
              className="md:hidden p-2 rounded-lg text-gray-400 hover:text-white hover:bg-white/5"
            >
              {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden bg-[#0d1b4b]/95 backdrop-blur-xl border-t border-white/10 py-4 animate-fade-in">
            {navLinks.map(link => (
              <button
                key={link.page}
                onClick={() => { onNavigate(link.page); setMenuOpen(false); }}
                className="flex w-full px-4 py-3 text-gray-300 hover:text-white hover:bg-white/5 transition-all"
              >
                {link.label}
              </button>
            ))}
            <div className="flex items-center gap-4 px-4 py-3 border-t border-white/10 mt-2">
              <button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} className="text-gray-400 hover:text-white text-sm">
                {lang === 'ar' ? 'English' : 'عربي'}
              </button>
              <button onClick={toggleDarkMode} className="text-gray-400 hover:text-white">
                {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
