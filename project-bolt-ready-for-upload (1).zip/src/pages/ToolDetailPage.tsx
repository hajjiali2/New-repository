import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../lib/supabase';
import { AI_TOOLS } from '../data/tools';
import { runOpenRouterTool } from '../lib/openrouter';
import * as Icons from 'lucide-react';
import { Zap, Copy, Download, Trash2, History, ArrowLeft, ArrowRight, Lock, Check, Loader2 } from 'lucide-react';

interface ToolDetailPageProps {
  toolId: string;
  onNavigate: (page: string) => void;
}

interface ResultItem {
  id: string;
  input: string;
  output: string;
  createdAt: string;
}

export default function ToolDetailPage({ toolId, onNavigate }: ToolDetailPageProps) {
  const { t, lang } = useApp();
  const { user, profile, refreshProfile } = useAuth();
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);
  const [results, setResults] = useState<ResultItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const tool = AI_TOOLS.find(t => t.id === toolId);
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  if (!tool) return (
    <div className="min-h-screen pt-20 flex items-center justify-center">
      <div className="text-center">
        <p className="text-gray-400">{t('الأداة غير موجودة', 'Tool not found')}</p>
        <button onClick={() => onNavigate('tools')} className="mt-4 text-orange-400">{t('العودة', 'Go back')}</button>
      </div>
    </div>
  );

  const IconComponent = (Icons as unknown as Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>>)[tool.icon] || Zap;

  const handleRun = async () => {
    if (!user) { onNavigate('login'); return; }
    if (!input.trim()) { setError(t('يرجى إدخال نص', 'Please enter text')); return; }
    if ((profile?.credits ?? 0) < tool.credits) {
      setError(t('رصيد غير كافٍ. يرجى الترقية', 'Insufficient credits. Please upgrade'));
      return;
    }

    setLoading(true);
    setError('');
    setOutput('');

    try {
      const result = await runOpenRouterTool({
        systemPrompt: tool.systemPrompt,
        userInput: input,
      });
      setOutput(result);

      // Save to DB
      await supabase.from('tool_results').insert({
        user_id: user.id,
        tool_id: tool.id,
        tool_name: tool.nameAr,
        input_data: { text: input },
        output_text: result,
        is_saved: false,
      });

      await supabase.from('tool_usage').insert({
        user_id: user.id,
        tool_id: tool.id,
        tool_name: tool.nameAr,
        credits_used: tool.credits,
        status: 'success',
      });

      await supabase.from('profiles').update({
        credits: (profile?.credits ?? 0) - tool.credits,
      }).eq('id', user.id);

      await refreshProfile();

      const newResult: ResultItem = {
        id: Date.now().toString(),
        input: input.slice(0, 80),
        output: result,
        createdAt: new Date().toLocaleString('ar-SA'),
      };
      setResults(prev => [newResult, ...prev.slice(0, 9)]);

    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : t('حدث خطأ', 'An error occurred');
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen pt-20">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Back */}
        <button
          onClick={() => onNavigate('tools')}
          className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-8 group"
        >
          <ArrowIcon className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
          {t('العودة للأدوات', 'Back to Tools')}
        </button>

        {/* Tool Header */}
        <div className="flex flex-col sm:flex-row items-start gap-5 mb-10">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-xl"
            style={{ background: `linear-gradient(135deg, ${tool.color}30, ${tool.color}15)`, border: `1px solid ${tool.color}30` }}
          >
            <IconComponent className="w-7 h-7" style={{ color: tool.color }} />
          </div>
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2 mb-1">
              <h1 className="text-3xl font-black text-white">{t(tool.nameAr, tool.nameEn)}</h1>
              {tool.isNew && <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-full text-xs">{t('جديد', 'New')}</span>}
              {tool.isPopular && <span className="px-2 py-0.5 bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-full text-xs">{t('شائع', 'Popular')}</span>}
            </div>
            <p className="text-gray-400 text-lg">{t(tool.descriptionAr, tool.descriptionEn)}</p>
            <div className="flex items-center gap-4 mt-3 text-sm">
              <span className="flex items-center gap-1.5 text-gray-400">
                <Zap className="w-3.5 h-3.5 text-orange-400" />
                {tool.credits} {t('رصيد لكل استخدام', 'credits per use')}
              </span>
              {user && (
                <span className="text-gray-500">
                  {t('رصيدك:', 'Your credits:')} <span className="text-white font-medium">{profile?.credits ?? 0}</span>
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Input Panel */}
          <div className="bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-white/8 flex items-center justify-between">
              <h3 className="text-white font-semibold">{t('المدخلات', 'Input')}</h3>
              <span className="text-xs text-gray-500">{input.length} {t('حرف', 'chars')}</span>
            </div>
            <div className="p-5">
              <textarea
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder={t(tool.inputPlaceholderAr, tool.inputPlaceholderEn)}
                rows={10}
                className="w-full bg-transparent text-white placeholder-gray-500 text-sm leading-relaxed focus:outline-none resize-none"
              />
            </div>
            <div className="px-5 py-4 border-t border-white/8">
              {!user ? (
                <button
                  onClick={() => onNavigate('login')}
                  className="w-full py-3 flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 rounded-xl transition-all text-sm"
                >
                  <Lock className="w-4 h-4" />
                  {t('سجل دخول للاستخدام', 'Sign in to use')}
                </button>
              ) : (
                <button
                  onClick={handleRun}
                  disabled={loading || !input.trim()}
                  className="w-full py-3 flex items-center justify-center gap-2 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 disabled:opacity-50 text-white font-semibold rounded-xl transition-all shadow-lg shadow-orange-500/20"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
                  {loading ? t('جاري التشغيل...', 'Running...') : t('تشغيل الأداة', 'Run Tool')}
                </button>
              )}
              {error && (
                <p className="text-red-400 text-sm mt-3 text-center">{error}</p>
              )}
            </div>
          </div>

          {/* Output Panel */}
          <div className="bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
            <div className="px-5 py-4 border-b border-white/8 flex items-center justify-between">
              <h3 className="text-white font-semibold">{t('النتيجة', 'Output')}</h3>
              {output && (
                <div className="flex items-center gap-2">
                  <button onClick={handleCopy} className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-xs text-gray-300 transition-all">
                    {copied ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                    {copied ? t('تم النسخ', 'Copied') : t('نسخ', 'Copy')}
                  </button>
                  <button
                    onClick={() => {
                      const blob = new Blob([output], { type: 'text/plain' });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement('a');
                      a.href = url;
                      a.download = `${tool.id}-result.txt`;
                      a.click();
                    }}
                    className="p-1.5 bg-white/5 hover:bg-white/10 rounded-lg text-gray-300 transition-all"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
            <div className="p-5 min-h-64">
              {loading ? (
                <div className="flex flex-col items-center justify-center h-48 gap-4">
                  <div className="relative w-12 h-12">
                    <div className="absolute inset-0 rounded-full border-2 border-orange-500/20" />
                    <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-orange-500 animate-spin" />
                    <Zap className="w-5 h-5 text-orange-400 absolute inset-0 m-auto" />
                  </div>
                  <p className="text-gray-400 text-sm animate-pulse">{t('يعمل الذكاء الاصطناعي...', 'AI is working...')}</p>
                </div>
              ) : output ? (
                <div className="text-gray-200 text-sm leading-relaxed whitespace-pre-wrap">{output}</div>
              ) : (
                <div className="flex flex-col items-center justify-center h-48 gap-3 text-gray-600">
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center opacity-30"
                    style={{ background: `${tool.color}15` }}
                  >
                    <IconComponent className="w-6 h-6" style={{ color: tool.color }} />
                  </div>
                  <p className="text-sm">{t('النتيجة ستظهر هنا', 'Results will appear here')}</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* History */}
        {results.length > 0 && (
          <div className="mt-8">
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors mb-4 text-sm"
            >
              <History className="w-4 h-4" />
              {t('السجل', 'History')} ({results.length})
            </button>
            {showHistory && (
              <div className="space-y-3">
                {results.map(r => (
                  <div key={r.id} className="bg-white/3 border border-white/8 rounded-xl p-4 flex items-start gap-4">
                    <div className="flex-1 min-w-0">
                      <p className="text-gray-400 text-xs mb-1 truncate">{t('المدخل:', 'Input:')} {r.input}</p>
                      <p className="text-white text-sm line-clamp-2">{r.output}</p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-xs text-gray-600">{r.createdAt}</span>
                      <button
                        onClick={() => {
                          setOutput(r.output);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        className="text-orange-400 hover:text-orange-300 text-xs"
                      >
                        {t('عرض', 'View')}
                      </button>
                      <button onClick={() => setResults(prev => prev.filter(x => x.id !== r.id))}>
                        <Trash2 className="w-3.5 h-3.5 text-gray-600 hover:text-red-400" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
