import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabase';
import { User, Key, Bell, Shield, Save, Plus, Trash2, Eye, EyeOff, Copy, Check, Loader2 } from 'lucide-react';

interface AccountPageProps {
  onNavigate: (page: string) => void;
}

interface ApiKey {
  id: string;
  name: string;
  key_prefix: string;
  is_active: boolean;
  last_used_at: string | null;
  created_at: string;
}

export default function AccountPage({ onNavigate }: AccountPageProps) {
  const { user, profile, refreshProfile } = useAuth();
  const { t } = useApp();
  const [activeTab, setActiveTab] = useState('profile');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({ full_name: '', company: '', phone: '' });
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [generatedKey, setGeneratedKey] = useState('');
  const [copiedKey, setCopiedKey] = useState(false);
  const [notifications, setNotifications] = useState<{ id: string; title: string; message: string; is_read: boolean; created_at: string }[]>([]);

  useEffect(() => {
    if (profile) setForm({ full_name: profile.full_name, company: profile.company || '', phone: profile.phone || '' });
    if (user) {
      supabase.from('api_keys').select('*').eq('user_id', user.id).then(({ data }) => setApiKeys(data || []));
      supabase.from('notifications').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(20).then(({ data }) => setNotifications(data || []));
    }
  }, [profile, user]);

  if (!user) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <button onClick={() => onNavigate('login')} className="px-6 py-2 bg-orange-500 text-white rounded-xl">
          {t('تسجيل الدخول', 'Sign In')}
        </button>
      </div>
    );
  }

  const handleSaveProfile = async () => {
    setSaving(true);
    await supabase.from('profiles').update({
      full_name: form.full_name,
      company: form.company,
      phone: form.phone,
      updated_at: new Date().toISOString(),
    }).eq('id', user.id);
    await refreshProfile();
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleGenerateKey = async () => {
    if (!newKeyName.trim()) return;
    const rawKey = `aih_${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
    const prefix = rawKey.slice(0, 12);
    const { data } = await supabase.from('api_keys').insert({
      user_id: user.id,
      name: newKeyName,
      key_prefix: prefix,
      key_hash: rawKey,
      is_active: true,
    }).select().maybeSingle();
    if (data) {
      setApiKeys(prev => [data, ...prev]);
      setGeneratedKey(rawKey);
      setNewKeyName('');
    }
  };

  const handleDeleteKey = async (id: string) => {
    await supabase.from('api_keys').delete().eq('id', id);
    setApiKeys(prev => prev.filter(k => k.id !== id));
  };

  const handleMarkAllRead = async () => {
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', user.id);
    setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
  };

  const tabs = [
    { id: 'profile', icon: User, label: t('الملف الشخصي', 'Profile') },
    { id: 'api-keys', icon: Key, label: t('مفاتيح API', 'API Keys') },
    { id: 'notifications', icon: Bell, label: t('الإشعارات', 'Notifications') },
    { id: 'security', icon: Shield, label: t('الأمان', 'Security') },
  ];

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-black text-white mb-8">{t('حسابي', 'My Account')}</h1>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar tabs */}
          <div className="md:w-56 flex md:flex-col gap-1.5 overflow-x-auto md:overflow-visible pb-2 md:pb-0">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2.5 px-4 py-3 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                  activeTab === tab.id
                    ? 'bg-orange-500/15 text-orange-400 border border-orange-500/20'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <tab.icon className="w-4 h-4 flex-shrink-0" />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div className="flex-1 bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 rounded-2xl p-6">
            {activeTab === 'profile' && (
              <div>
                <h2 className="text-white font-bold text-lg mb-6">{t('معلومات الحساب', 'Account Information')}</h2>
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-16 h-16 bg-gradient-to-br from-orange-400 to-orange-600 rounded-2xl flex items-center justify-center text-2xl font-black text-white">
                    {profile?.full_name?.charAt(0) || user.email?.charAt(0)?.toUpperCase()}
                  </div>
                  <div>
                    <p className="text-white font-semibold text-lg">{profile?.full_name}</p>
                    <p className="text-gray-400 text-sm">{user.email}</p>
                    <span className="mt-1 inline-block px-2.5 py-0.5 bg-orange-500/15 text-orange-400 border border-orange-500/20 rounded-full text-xs font-medium capitalize">
                      {profile?.plan} plan
                    </span>
                  </div>
                </div>

                <div className="grid gap-4">
                  {[
                    { key: 'full_name', label: t('الاسم الكامل', 'Full Name'), type: 'text' },
                    { key: 'company', label: t('الشركة', 'Company'), type: 'text' },
                    { key: 'phone', label: t('رقم الهاتف', 'Phone'), type: 'tel' },
                  ].map(field => (
                    <div key={field.key}>
                      <label className="text-sm text-gray-400 mb-1.5 block">{field.label}</label>
                      <input
                        type={field.type}
                        value={form[field.key as keyof typeof form]}
                        onChange={e => setForm(p => ({ ...p, [field.key]: e.target.value }))}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                      />
                    </div>
                  ))}
                  <div>
                    <label className="text-sm text-gray-400 mb-1.5 block">{t('البريد الإلكتروني', 'Email')}</label>
                    <input
                      type="email"
                      value={user.email || ''}
                      disabled
                      className="w-full bg-white/3 border border-white/5 rounded-xl px-4 py-2.5 text-gray-500 text-sm cursor-not-allowed"
                    />
                  </div>
                  <button
                    onClick={handleSaveProfile}
                    disabled={saving}
                    className="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-orange-600 text-white font-semibold rounded-xl hover:from-orange-600 hover:to-orange-700 transition-all disabled:opacity-60 w-full sm:w-auto"
                  >
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : saved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
                    {saving ? t('جاري الحفظ...', 'Saving...') : saved ? t('تم الحفظ!', 'Saved!') : t('حفظ التغييرات', 'Save Changes')}
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'api-keys' && (
              <div>
                <h2 className="text-white font-bold text-lg mb-2">{t('مفاتيح API', 'API Keys')}</h2>
                <p className="text-gray-400 text-sm mb-6">{t('استخدم مفاتيح API للوصول للمنصة من تطبيقاتك الخارجية', 'Use API keys to access the platform from your external applications')}</p>

                {generatedKey && (
                  <div className="mb-6 p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
                    <p className="text-green-400 text-sm font-medium mb-2">{t('تم إنشاء المفتاح! انسخه الآن - لن يظهر مرة أخرى', 'Key created! Copy it now - it won\'t show again')}</p>
                    <div className="flex items-center gap-2 bg-white/5 rounded-lg px-3 py-2">
                      <code className="text-green-300 text-xs flex-1 truncate">{generatedKey}</code>
                      <button
                        onClick={() => { navigator.clipboard.writeText(generatedKey); setCopiedKey(true); setTimeout(() => setCopiedKey(false), 2000); }}
                        className="text-gray-400 hover:text-white"
                      >
                        {copiedKey ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex gap-3 mb-6">
                  <input
                    type="text"
                    placeholder={t('اسم المفتاح...', 'Key name...')}
                    value={newKeyName}
                    onChange={e => setNewKeyName(e.target.value)}
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-orange-500/50"
                  />
                  <button
                    onClick={handleGenerateKey}
                    disabled={!newKeyName.trim()}
                    className="flex items-center gap-2 px-5 py-2.5 bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white text-sm font-medium rounded-xl transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    {t('إنشاء', 'Generate')}
                  </button>
                </div>

                {apiKeys.length === 0 ? (
                  <div className="text-center py-10 text-gray-500">
                    <Key className="w-8 h-8 mx-auto mb-3 opacity-30" />
                    <p className="text-sm">{t('لا توجد مفاتيح API حتى الآن', 'No API keys yet')}</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {apiKeys.map(key => (
                      <div key={key.id} className="flex items-center justify-between p-4 bg-white/3 border border-white/8 rounded-xl">
                        <div>
                          <p className="text-white font-medium text-sm">{key.name}</p>
                          <p className="text-gray-500 text-xs mt-0.5 font-mono">{key.key_prefix}••••••••</p>
                          <p className="text-gray-600 text-xs">{new Date(key.created_at).toLocaleDateString('ar-SA')}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className={`px-2 py-0.5 rounded-full text-xs ${key.is_active ? 'bg-green-500/15 text-green-400' : 'bg-gray-500/15 text-gray-400'}`}>
                            {key.is_active ? t('نشط', 'Active') : t('معطل', 'Inactive')}
                          </span>
                          <button onClick={() => handleDeleteKey(key.id)} className="p-1.5 text-gray-600 hover:text-red-400 transition-colors">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'notifications' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-white font-bold text-lg">{t('الإشعارات', 'Notifications')}</h2>
                  {notifications.some(n => !n.is_read) && (
                    <button onClick={handleMarkAllRead} className="text-orange-400 hover:text-orange-300 text-sm">
                      {t('تعليم الكل كمقروء', 'Mark all read')}
                    </button>
                  )}
                </div>
                {notifications.length === 0 ? (
                  <div className="text-center py-12 text-gray-500">
                    <Bell className="w-8 h-8 mx-auto mb-3 opacity-30" />
                    <p className="text-sm">{t('لا توجد إشعارات', 'No notifications')}</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {notifications.map(n => (
                      <div key={n.id} className={`p-4 rounded-xl border transition-all ${n.is_read ? 'bg-white/2 border-white/5' : 'bg-orange-500/5 border-orange-500/15'}`}>
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <p className={`text-sm font-medium ${n.is_read ? 'text-gray-400' : 'text-white'}`}>{n.title}</p>
                            <p className="text-gray-500 text-xs mt-0.5">{n.message}</p>
                          </div>
                          {!n.is_read && <span className="w-2 h-2 bg-orange-400 rounded-full flex-shrink-0 mt-1" />}
                        </div>
                        <p className="text-gray-600 text-xs mt-2">{new Date(n.created_at).toLocaleDateString('ar-SA')}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'security' && (
              <div>
                <h2 className="text-white font-bold text-lg mb-6">{t('الأمان والخصوصية', 'Security & Privacy')}</h2>
                <div className="space-y-4">
                  <div className="p-4 bg-white/3 border border-white/8 rounded-xl">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium text-sm">{t('كلمة المرور', 'Password')}</p>
                        <p className="text-gray-500 text-xs">{t('آخر تغيير: غير محدد', 'Last changed: unknown')}</p>
                      </div>
                      <button className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 text-sm rounded-xl transition-all">
                        {t('تغيير', 'Change')}
                      </button>
                    </div>
                  </div>
                  <div className="p-4 bg-white/3 border border-white/8 rounded-xl">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white font-medium text-sm">{t('المصادقة الثنائية', '2FA Authentication')}</p>
                        <p className="text-gray-500 text-xs">{t('تعزيز أمان حسابك', 'Enhance your account security')}</p>
                      </div>
                      <span className="px-2.5 py-1 bg-gray-500/20 text-gray-400 rounded-full text-xs">{t('قريباً', 'Coming Soon')}</span>
                    </div>
                  </div>
                  <div className="p-4 bg-red-500/5 border border-red-500/10 rounded-xl">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-red-400 font-medium text-sm">{t('حذف الحساب', 'Delete Account')}</p>
                        <p className="text-gray-500 text-xs">{t('هذا الإجراء لا يمكن التراجع عنه', 'This action cannot be undone')}</p>
                      </div>
                      <button className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 text-sm rounded-xl transition-all">
                        {t('حذف', 'Delete')}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
