import { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabase';
import { AI_TOOLS } from '../data/tools';
import ToolCard from '../components/ToolCard';
import { ArrowLeft, ArrowRight, Zap, Shield, Globe as Globe2, Users, Star, ChevronDown, CheckCircle, Brain, Sparkles, TrendingUp, Building2, Send } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string, toolId?: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const { t, lang } = useApp();
  const [faqOpen, setFaqOpen] = useState<number | null>(null);
  const [leadForm, setLeadForm] = useState({ name: '', email: '', company: '', message: '' });
  const [leadSubmitted, setLeadSubmitted] = useState(false);
  const [leadLoading, setLeadLoading] = useState(false);

  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  const stats = [
    { value: '10,000+', label: t('مستخدم نشط', 'Active Users') },
    { value: '15+', label: t('أداة ذكاء اصطناعي', 'AI Tools') },
    { value: '500K+', label: t('مهمة منجزة', 'Tasks Completed') },
    { value: '99.9%', label: t('وقت التشغيل', 'Uptime') },
  ];

  const features = [
    {
      icon: Zap,
      titleAr: 'سرعة فائقة',
      titleEn: 'Lightning Fast',
      descAr: 'نتائج في ثوانٍ معدودة بفضل أحدث نماذج الذكاء الاصطناعي',
      descEn: 'Results in seconds using the latest AI models',
      color: '#f97316',
    },
    {
      icon: Shield,
      titleAr: 'آمن وموثوق',
      titleEn: 'Secure & Reliable',
      descAr: 'بياناتك محمية بأعلى معايير الأمان والتشفير',
      descEn: 'Your data is protected with the highest security standards',
      color: '#10b981',
    },
    {
      icon: Globe2,
      titleAr: 'دعم العربية',
      titleEn: 'Arabic Support',
      descAr: 'الأداة الأولى عربياً مع دعم كامل للغة العربية RTL',
      descEn: 'First Arabic tool with full RTL Arabic language support',
      color: '#3b82f6',
    },
    {
      icon: Users,
      titleAr: 'للفرق والشركات',
      titleEn: 'For Teams',
      descAr: 'إدارة الفريق وتتبع الاستخدام بلوحة تحكم متكاملة',
      descEn: 'Team management and usage tracking with integrated dashboard',
      color: '#8b5cf6',
    },
  ];

  const testimonials = [
    {
      name: 'أحمد الشهري',
      titleAr: 'مدير تسويق - شركة الأمانة',
      titleEn: 'Marketing Manager - Al Amana Co.',
      textAr: 'AI Hub Arabia غيّر طريقة عملنا بالكامل. الآن ننتج محتوى أسرع بـ 10 مرات وبجودة أعلى.',
      textEn: 'AI Hub Arabia completely changed our workflow. Now we produce content 10x faster and with higher quality.',
      rating: 5,
    },
    {
      name: 'سارة المطيري',
      titleAr: 'مؤسسة شركة ناشئة',
      titleEn: 'Startup Founder',
      textAr: 'أدوات كتابة العقود وخطط الأعمال وفّرت عليّ الكثير من الوقت والمال.',
      textEn: 'Contract writing and business plan tools saved me a lot of time and money.',
      rating: 5,
    },
    {
      name: 'محمد العسيري',
      titleAr: 'رائد أعمال في دبي',
      titleEn: 'Entrepreneur in Dubai',
      textAr: 'الأفضل عربياً بلا منافس. سهل الاستخدام ونتائجه احترافية جداً.',
      textEn: 'Best in Arabic with no competition. Easy to use with very professional results.',
      rating: 5,
    },
  ];

  const faqs = [
    {
      qAr: 'كيف تعمل الأرصدة؟',
      qEn: 'How do credits work?',
      aAr: 'كل أداة تستهلك عدداً معيناً من الأرصدة. تبدأ بـ 50 رصيد مجاناً عند التسجيل، ويمكنك الترقية للحصول على المزيد.',
      aEn: 'Each tool consumes a certain number of credits. You start with 50 free credits upon registration and can upgrade for more.',
    },
    {
      qAr: 'هل يمكنني تجربة المنصة مجاناً؟',
      qEn: 'Can I try the platform for free?',
      aAr: 'نعم! التسجيل مجاني وتحصل على 50 رصيد فور إنشاء حسابك لتجربة أي أدوات تريدها.',
      aEn: 'Yes! Registration is free and you get 50 credits immediately upon creating your account to try any tools you want.',
    },
    {
      qAr: 'هل تدعم المنصة اللغة العربية بالكامل؟',
      qEn: 'Does the platform fully support Arabic?',
      aAr: 'نعم، المنصة مبنية خصيصاً للعرب مع دعم RTL كامل وخطوط عربية احترافية وجميع المحتوى باللغة العربية.',
      aEn: 'Yes, the platform is built specifically for Arabs with full RTL support, professional Arabic fonts, and all content in Arabic.',
    },
    {
      qAr: 'هل بيانات الشركة آمنة؟',
      qEn: 'Is company data safe?',
      aAr: 'أمان بياناتك أولويتنا القصوى. نستخدم تشفير AES-256 ولا نشارك بياناتك مع أي طرف ثالث.',
      aEn: 'Your data security is our top priority. We use AES-256 encryption and never share your data with third parties.',
    },
    {
      qAr: 'ما هي الفرق بين الخطط؟',
      qEn: 'What are the differences between plans?',
      aAr: 'الخطة المجانية تمنحك 50 رصيد و5 أدوات. الاحترافية تمنحك 1000 رصيد وجميع الأدوات. المؤسسية غير محدودة.',
      aEn: 'The free plan gives you 50 credits and 5 tools. Professional gives 1000 credits and all tools. Enterprise is unlimited.',
    },
  ];

  const companies = ['Saudi Aramco', 'SABIC', 'STC', 'Noon', 'Jarir', 'Mobily'];

  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLeadLoading(true);
    await supabase.from('leads').insert({
      name: leadForm.name,
      email: leadForm.email,
      company: leadForm.company,
      message: leadForm.message,
      source: 'landing_page',
      status: 'new',
    });
    setLeadLoading(false);
    setLeadSubmitted(true);
  };

  const popularTools = AI_TOOLS.filter(t => t.isPopular).slice(0, 6);

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-br from-[#060f33] via-[#0d1b4b] to-[#060f33]" />
          <div className="absolute top-1/4 start-1/4 w-96 h-96 bg-orange-500/10 rounded-full filter blur-3xl animate-pulse" />
          <div className="absolute bottom-1/4 end-1/4 w-96 h-96 bg-blue-600/8 rounded-full filter blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
          {/* Grid */}
          <div className="absolute inset-0 opacity-30" style={{
            backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.05) 1px, transparent 0)',
            backgroundSize: '40px 40px',
          }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 lg:py-40">
          <div className="max-w-4xl mx-auto text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-500/10 border border-orange-500/20 rounded-full mb-8 animate-fade-in">
              <Sparkles className="w-4 h-4 text-orange-400" />
              <span className="text-orange-300 text-sm font-medium">
                {t('منصة الذكاء الاصطناعي #1 عربياً', 'The #1 Arabic AI Platform')}
              </span>
            </div>

            {/* Headline */}
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-black text-white leading-tight mb-6 animate-slide-up">
              {t(
                <>أدوات <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">ذكاء اصطناعي</span><br />تُسرّع أعمالك</>,
                <>AI Tools That<br /><span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-orange-600">Accelerate</span> Your Business</>
              )}
            </h1>

            <p className="text-xl text-gray-300 leading-relaxed mb-10 max-w-2xl mx-auto animate-slide-up" style={{ animationDelay: '0.1s' }}>
              {t(
                'أكثر من 15 أداة ذكاء اصطناعي متطورة لكتابة المحتوى، تحليل البيانات، إنشاء العقود، وأتمتة عمليات شركتك.',
                'Over 15 advanced AI tools for content writing, data analysis, contract creation, and automating your business operations.'
              )}
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '0.2s' }}>
              <button
                onClick={() => onNavigate('register')}
                className="group flex items-center gap-3 px-8 py-4 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold rounded-2xl shadow-xl shadow-orange-500/30 hover:shadow-orange-500/50 transition-all hover:scale-105 text-lg"
              >
                <Zap className="w-5 h-5" />
                {t('ابدأ مجاناً الآن', 'Start Free Now')}
                <ArrowIcon className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button
                onClick={() => onNavigate('tools')}
                className="flex items-center gap-2 px-8 py-4 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 text-white font-semibold rounded-2xl transition-all text-lg"
              >
                {t('استكشف الأدوات', 'Explore Tools')}
              </button>
            </div>

            {/* Trust badges */}
            <div className="flex flex-wrap items-center justify-center gap-6 mt-12 text-sm text-gray-400 animate-fade-in" style={{ animationDelay: '0.4s' }}>
              {[
                { icon: CheckCircle, text: t('50 رصيد مجاناً', '50 free credits') },
                { icon: CheckCircle, text: t('لا يوجد بطاقة ائتمان', 'No credit card required') },
                { icon: CheckCircle, text: t('إلغاء في أي وقت', 'Cancel anytime') },
              ].map(({ icon: Icon, text }, i) => (
                <span key={i} className="flex items-center gap-1.5">
                  <Icon className="w-4 h-4 text-green-400" />
                  {text}
                </span>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20 max-w-3xl mx-auto">
            {stats.map((stat, i) => (
              <div key={i} className="text-center p-5 bg-white/3 border border-white/8 rounded-2xl backdrop-blur-sm animate-slide-up" style={{ animationDelay: `${0.3 + i * 0.1}s` }}>
                <div className="text-3xl font-black text-white mb-1">{stat.value}</div>
                <div className="text-sm text-gray-400">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trusted By */}
      <section className="py-14 border-y border-white/5 bg-white/[0.01]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-500 text-sm mb-8 uppercase tracking-widest">
            {t('موثوق من قِبَل شركات رائدة', 'Trusted by leading companies')}
          </p>
          <div className="flex flex-wrap items-center justify-center gap-8 md:gap-14">
            {companies.map((company, i) => (
              <div key={i} className="text-gray-600 font-bold text-lg hover:text-gray-400 transition-colors cursor-default">
                {company}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full mb-4">
              <Brain className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-blue-300 text-xs font-medium">{t('لماذا نحن', 'Why Us')}</span>
            </div>
            <h2 className="text-4xl lg:text-5xl font-black text-white mb-4">
              {t('مزايا لا مثيل لها', 'Unmatched Advantages')}
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto">
              {t(
                'بنيّنا المنصة لتكون الأسرع والأذكى والأكثر ملاءمة للسوق العربي',
                'We built the platform to be the fastest, smartest, and most suitable for the Arab market'
              )}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f, i) => (
              <div key={i} className="group p-6 bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 hover:border-white/15 rounded-2xl transition-all hover:-translate-y-1">
                <div
                  className="w-12 h-12 rounded-2xl flex items-center justify-center mb-5"
                  style={{ background: `${f.color}20`, border: `1px solid ${f.color}30` }}
                >
                  <f.icon className="w-5.5 h-5.5" style={{ color: f.color }} />
                </div>
                <h3 className="text-white font-bold text-lg mb-2">{t(f.titleAr, f.titleEn)}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{t(f.descAr, f.descEn)}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Tools */}
      <section className="py-24 bg-white/[0.02] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-end justify-between mb-12">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-500/10 border border-orange-500/20 rounded-full mb-4">
                <TrendingUp className="w-3.5 h-3.5 text-orange-400" />
                <span className="text-orange-300 text-xs font-medium">{t('الأدوات', 'Tools')}</span>
              </div>
              <h2 className="text-4xl font-black text-white">
                {t('الأدوات الأكثر استخداماً', 'Most Popular Tools')}
              </h2>
            </div>
            <button
              onClick={() => onNavigate('tools')}
              className="hidden md:flex items-center gap-2 text-orange-400 hover:text-orange-300 font-medium transition-colors"
            >
              {t('عرض الكل', 'View All')}
              <ArrowIcon className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {popularTools.map(tool => (
              <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} />
            ))}
          </div>
          <div className="text-center mt-8">
            <button
              onClick={() => onNavigate('tools')}
              className="px-8 py-3 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-2xl font-medium transition-all"
            >
              {t('عرض جميع الأدوات (15+)', 'View All Tools (15+)')}
            </button>
          </div>
        </div>
      </section>

      {/* Enterprise Section */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-[#0d1b4b] to-[#111c4a] border border-white/10 rounded-3xl p-10 lg:p-16 relative overflow-hidden">
            <div className="absolute inset-0 bg-grid-pattern opacity-30" />
            <div className="absolute top-0 end-0 w-64 h-64 bg-orange-500/10 rounded-full filter blur-3xl" />
            <div className="relative grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-500/10 border border-orange-500/20 rounded-full mb-6">
                  <Building2 className="w-3.5 h-3.5 text-orange-400" />
                  <span className="text-orange-300 text-xs font-medium">{t('للمؤسسات', 'Enterprise')}</span>
                </div>
                <h2 className="text-4xl font-black text-white mb-4">
                  {t('حلول مخصصة للمؤسسات', 'Custom Enterprise Solutions')}
                </h2>
                <p className="text-gray-300 mb-8 leading-relaxed">
                  {t(
                    'نقدم حلولاً مؤسسية مخصصة مع API مدمج، دعم مخصص، وإمكانية تطوير أدوات خاصة بشركتك.',
                    'We offer custom enterprise solutions with integrated API, dedicated support, and the ability to develop tools specific to your company.'
                  )}
                </p>
                <ul className="space-y-3 mb-8">
                  {[
                    t('API غير محدود بـ SLA 99.9%', 'Unlimited API with 99.9% SLA'),
                    t('مدير حساب مخصص', 'Dedicated account manager'),
                    t('تكامل مع أنظمة الشركة', 'Integration with company systems'),
                    t('تدريب للفريق', 'Team training'),
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-gray-300">
                      <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
                <button
                  onClick={() => onNavigate('contact')}
                  className="px-6 py-3 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold rounded-xl shadow-lg shadow-orange-500/25 transition-all hover:scale-105"
                >
                  {t('طلب عرض سعر', 'Request a Quote')}
                </button>
              </div>

              {/* Lead form */}
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
                {leadSubmitted ? (
                  <div className="text-center py-8">
                    <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
                    <h3 className="text-white font-bold text-xl mb-2">{t('تم الإرسال!', 'Sent!')}</h3>
                    <p className="text-gray-400">{t('سنتواصل معك خلال 24 ساعة', 'We\'ll contact you within 24 hours')}</p>
                  </div>
                ) : (
                  <form onSubmit={handleLeadSubmit} className="space-y-4">
                    <h3 className="text-white font-bold text-lg mb-5">
                      {t('طلب عرض سعر مجاني', 'Request Free Quote')}
                    </h3>
                    {[
                      { key: 'name', label: t('الاسم', 'Name'), type: 'text', required: true },
                      { key: 'email', label: t('البريد الإلكتروني', 'Email'), type: 'email', required: true },
                      { key: 'company', label: t('الشركة', 'Company'), type: 'text', required: false },
                    ].map(field => (
                      <div key={field.key}>
                        <label className="text-sm text-gray-400 mb-1.5 block">{field.label}</label>
                        <input
                          type={field.type}
                          required={field.required}
                          value={leadForm[field.key as keyof typeof leadForm]}
                          onChange={e => setLeadForm(prev => ({ ...prev, [field.key]: e.target.value }))}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                        />
                      </div>
                    ))}
                    <div>
                      <label className="text-sm text-gray-400 mb-1.5 block">{t('رسالة', 'Message')}</label>
                      <textarea
                        rows={3}
                        value={leadForm.message}
                        onChange={e => setLeadForm(prev => ({ ...prev, message: e.target.value }))}
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-orange-500/50 transition-colors resize-none"
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={leadLoading}
                      className="w-full py-3 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold rounded-xl flex items-center justify-center gap-2 transition-all disabled:opacity-60"
                    >
                      {leadLoading ? (
                        <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          {t('إرسال الطلب', 'Send Request')}
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-white/[0.02] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-4xl font-black text-white mb-3">{t('ماذا يقول عملاؤنا', 'What Our Clients Say')}</h2>
            <p className="text-gray-400">{t('آراء حقيقية من شركات تستخدم المنصة يومياً', 'Real opinions from companies that use the platform daily')}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((tm, i) => (
              <div key={i} className="bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 rounded-2xl p-6">
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: tm.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 fill-orange-400 text-orange-400" />
                  ))}
                </div>
                <p className="text-gray-300 text-sm leading-relaxed mb-5">"{t(tm.textAr, tm.textEn)}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-gradient-to-br from-orange-400 to-orange-600 rounded-xl flex items-center justify-center text-white font-bold text-sm">
                    {tm.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-white font-medium text-sm">{tm.name}</p>
                    <p className="text-gray-500 text-xs">{t(tm.titleAr, tm.titleEn)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-24">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <h2 className="text-4xl font-black text-white mb-3">{t('الأسئلة الشائعة', 'FAQ')}</h2>
            <p className="text-gray-400">{t('إجابات على أكثر الأسئلة تكراراً', 'Answers to the most frequently asked questions')}</p>
          </div>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-white/3 border border-white/8 rounded-2xl overflow-hidden">
                <button
                  onClick={() => setFaqOpen(faqOpen === i ? null : i)}
                  className="w-full flex items-center justify-between px-6 py-4 text-start"
                >
                  <span className="text-white font-medium">{t(faq.qAr, faq.qEn)}</span>
                  <ChevronDown className={`w-4 h-4 text-gray-400 flex-shrink-0 transition-transform ${faqOpen === i ? 'rotate-180' : ''}`} />
                </button>
                {faqOpen === i && (
                  <div className="px-6 pb-5 text-gray-400 text-sm leading-relaxed border-t border-white/5 pt-4">
                    {t(faq.aAr, faq.aEn)}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-gradient-to-r from-orange-500/10 to-orange-600/5 border border-orange-500/20 rounded-3xl p-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-grid-pattern opacity-20" />
            <div className="relative">
              <h2 className="text-4xl font-black text-white mb-4">
                {t('جاهز لتسريع أعمالك؟', 'Ready to Accelerate Your Business?')}
              </h2>
              <p className="text-gray-300 mb-8 text-lg">
                {t('انضم لأكثر من 10,000 شركة ورائد أعمال يستخدمون AI Hub Arabia', 'Join over 10,000 companies and entrepreneurs using AI Hub Arabia')}
              </p>
              <button
                onClick={() => onNavigate('register')}
                className="px-10 py-4 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-bold rounded-2xl shadow-2xl shadow-orange-500/30 hover:shadow-orange-500/50 transition-all hover:scale-105 text-lg"
              >
                {t('ابدأ مجاناً الآن', 'Start Free Now')}
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
