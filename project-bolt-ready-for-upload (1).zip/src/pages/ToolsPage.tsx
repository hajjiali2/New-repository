import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AI_TOOLS, TOOL_CATEGORIES } from '../data/tools';
import ToolCard from '../components/ToolCard';
import { Search, Sliders, Sparkles } from 'lucide-react';

interface ToolsPageProps {
  onNavigate: (page: string, toolId?: string) => void;
}

export default function ToolsPage({ onNavigate }: ToolsPageProps) {
  const { t } = useApp();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortBy, setSortBy] = useState('popular');

  const filtered = AI_TOOLS
    .filter(tool => {
      const matchSearch = !search ||
        tool.nameAr.includes(search) ||
        tool.nameEn.toLowerCase().includes(search.toLowerCase()) ||
        tool.descriptionAr.includes(search);
      const matchCategory = activeCategory === 'all' || tool.category === activeCategory;
      return matchSearch && matchCategory;
    })
    .sort((a, b) => {
      if (sortBy === 'popular') return (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0);
      if (sortBy === 'credits-asc') return a.credits - b.credits;
      if (sortBy === 'credits-desc') return b.credits - a.credits;
      return 0;
    });

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <div className="bg-gradient-to-b from-[#0d1b4b]/50 to-transparent py-16 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-500/10 border border-orange-500/20 rounded-full mb-4">
            <Sparkles className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-orange-300 text-xs font-medium">{AI_TOOLS.length} {t('أداة متاحة', 'tools available')}</span>
          </div>
          <h1 className="text-4xl lg:text-5xl font-black text-white mb-4">
            {t('مركز أدوات الذكاء الاصطناعي', 'AI Tools Hub')}
          </h1>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            {t(
              'اختر الأداة المناسبة من مجموعتنا المتكاملة من أدوات الذكاء الاصطناعي',
              'Choose the right tool from our comprehensive collection of AI tools'
            )}
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute start-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder={t('ابحث عن أداة...', 'Search for a tool...')}
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl ps-11 pe-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
            />
          </div>
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-gray-400" />
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value)}
              className="bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500/50 transition-colors cursor-pointer"
            >
              <option value="popular" className="bg-[#0d1b4b]">{t('الأكثر شعبية', 'Most Popular')}</option>
              <option value="credits-asc" className="bg-[#0d1b4b]">{t('الأقل رصيداً', 'Least Credits')}</option>
              <option value="credits-desc" className="bg-[#0d1b4b]">{t('الأكثر رصيداً', 'Most Credits')}</option>
            </select>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap gap-2 mb-8 overflow-x-auto pb-2">
          {TOOL_CATEGORIES.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                activeCategory === cat.id
                  ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/25'
                  : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10 border border-white/8'
              }`}
            >
              {t(cat.nameAr, cat.nameEn)}
            </button>
          ))}
        </div>

        {/* Results count */}
        <div className="mb-6 text-sm text-gray-500">
          {t(`${filtered.length} أداة`, `${filtered.length} tools`)}
          {search && t(` بحثاً عن "${search}"`, ` for "${search}"`)}
        </div>

        {/* Tools Grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map(tool => (
              <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-semibold text-lg mb-2">{t('لا توجد أدوات', 'No tools found')}</h3>
            <p className="text-gray-400 text-sm">{t('جرب البحث بكلمات مختلفة', 'Try searching with different words')}</p>
          </div>
        )}
      </div>
    </div>
  );
}
