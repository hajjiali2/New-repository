import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PERSONAL_TOOLS, TOOL_CATEGORIES } from '../data/tools';
import ToolCard from '../components/ToolCard';
import { Search, UserRound, Sparkles, Briefcase, GraduationCap, WalletCards } from 'lucide-react';

interface IndividualsPageProps {
  onNavigate: (page: string, toolId?: string) => void;
}

const personalCategoryIds = ['all', 'personal-career', 'personal-writing', 'personal-study', 'personal-money'];

export default function IndividualsPage({ onNavigate }: IndividualsPageProps) {
  const { t } = useApp();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = TOOL_CATEGORIES.filter(cat => personalCategoryIds.includes(cat.id));
  const filtered = PERSONAL_TOOLS.filter(tool => {
    const matchSearch = !search ||
      tool.nameAr.includes(search) ||
      tool.nameEn.toLowerCase().includes(search.toLowerCase()) ||
      tool.descriptionAr.includes(search);
    const matchCategory = activeCategory === 'all' || tool.category === activeCategory;
    return matchSearch && matchCategory;
  });

  return (
    <div className="min-h-screen pt-20">
      <section className="relative overflow-hidden bg-gradient-to-b from-orange-500/10 via-[#0d1b4b]/40 to-transparent py-16 border-b border-white/5">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-10 start-10 w-72 h-72 bg-orange-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-0 end-10 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-500/10 border border-orange-500/20 rounded-full mb-5">
            <UserRound className="w-4 h-4 text-orange-400" />
            <span className="text-orange-300 text-sm font-semibold">{t('أدوات للأفراد', 'Tools for Individuals')}</span>
          </div>
          <h1 className="text-4xl lg:text-6xl font-black text-white mb-5 leading-tight">
            {t('ذكاء اصطناعي يساعدك في عملك ودراستك ودخلك', 'AI tools for your work, study, and income')}
          </h1>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto leading-relaxed">
            {t(
              'مجموعة أدوات عربية ذكية تساعدك على كتابة السيرة الذاتية، تجهيز المقابلات، تلخيص النصوص، إنشاء أفكار مشاريع، وكتابة الرسائل والخطابات باحتراف.',
              'Arabic AI tools to help you write CVs, prepare interviews, summarize text, generate project ideas, and write professional messages.'
            )}
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-10 max-w-4xl mx-auto">
            {[
              { icon: Briefcase, title: t('وظائف ومقابلات', 'Career'), text: t('CV ومقابلات', 'CV & interviews') },
              { icon: GraduationCap, title: t('دراسة وإنتاجية', 'Study'), text: t('شرح وتلخيص', 'Explain & summarize') },
              { icon: WalletCards, title: t('دخل ومشاريع', 'Income'), text: t('أفكار وخطط', 'Ideas & plans') },
            ].map((item, idx) => (
              <div key={idx} className="bg-white/5 border border-white/10 rounded-2xl p-5 text-start">
                <item.icon className="w-7 h-7 text-orange-400 mb-3" />
                <h3 className="text-white font-bold mb-1">{item.title}</h3>
                <p className="text-gray-400 text-sm">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute start-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder={t('ابحث عن أداة للأفراد...', 'Search personal tools...')}
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded-xl ps-11 pe-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
            />
          </div>
          <button
            onClick={() => onNavigate('tools')}
            className="px-5 py-3 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-200 rounded-xl transition-all text-sm font-semibold"
          >
            {t('أدوات الشركات', 'Business Tools')}
          </button>
        </div>

        <div className="flex flex-wrap gap-2 mb-8 overflow-x-auto pb-2">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-all ${
                activeCategory === cat.id
                  ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/25'
                  : 'bg-white/5 text-gray-400 hover:text-white hover:bg-white/10 border border-white/8'
              }`}
            >
              {t(cat.nameAr.replace('للأفراد - ', ''), cat.nameEn.replace('Individuals - ', ''))}
            </button>
          ))}
        </div>

        <div className="mb-6 flex items-center gap-2 text-sm text-gray-500">
          <Sparkles className="w-4 h-4 text-orange-400" />
          {t(`${filtered.length} أداة للأفراد`, `${filtered.length} personal tools`)}
        </div>

        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {filtered.map(tool => (
              <ToolCard key={tool.id} tool={tool} onNavigate={onNavigate} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
            <h3 className="text-white font-semibold text-lg mb-2">{t('لا توجد أدوات', 'No tools found')}</h3>
            <p className="text-gray-400 text-sm">{t('جرب البحث بكلمات مختلفة', 'Try searching with different words')}</p>
          </div>
        )}
      </section>
    </div>
  );
}
