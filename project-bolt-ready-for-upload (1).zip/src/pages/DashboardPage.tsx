import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabase';
import { AI_TOOLS } from '../data/tools';
import {
  Zap, BarChart2, Clock, TrendingUp, Award, ArrowRight, ArrowLeft,
  Brain, Settings, Key, Bell, User, ChevronRight, Activity,
} from 'lucide-react';
import * as Icons from 'lucide-react';

interface DashboardPageProps {
  onNavigate: (page: string, toolId?: string) => void;
}

interface UsageItem {
  id: string;
  tool_name: string;
  credits_used: number;
  status: string;
  created_at: string;
}

export default function DashboardPage({ onNavigate }: DashboardPageProps) {
  const { user, profile } = useAuth();
  const { t, lang } = useApp();
  const [usage, setUsage] = useState<UsageItem[]>([]);
  const [loading, setLoading] = useState(true);
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  useEffect(() => {
    if (!user) return;
    const fetchUsage = async () => {
      const { data } = await supabase
        .from('tool_usage')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(10);
      setUsage(data || []);
      setLoading(false);
    };
    fetchUsage();
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-400 mb-4">{t('يجب تسجيل الدخول أولاً', 'Please sign in first')}</p>
          <button onClick={() => onNavigate('login')} className="px-6 py-2 bg-orange-500 text-white rounded-xl">
            {t('تسجيل الدخول', 'Sign In')}
          </button>
        </div>
      </div>
    );
  }

  const totalCreditsUsed = usage.reduce((sum, u) => sum + u.credits_used, 0);
  const planColor = profile?.plan === 'enterprise' ? '#3b82f6' : profile?.plan === 'pro' ? '#f97316' : '#6b7280';

  const quickActions = AI_TOOLS.slice(0, 6).map(tool => ({
    tool,
    icon: (Icons as unknown as Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>>)[tool.icon] || Zap,
  }));

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-10">
          <div>
            <h1 className="text-3xl font-black text-white mb-1">
              {t(`مرحباً، ${profile?.full_name?.split(' ')[0] || 'مستخدم'}!`, `Welcome, ${profile?.full_name?.split(' ')[0] || 'User'}!`)}
            </h1>
            <p className="text-gray-400">{t('لوحة تحكم حسابك', 'Your account dashboard')}</p>
          </div>
          <button
            onClick={() => onNavigate('tools')}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-orange-500 to-orange-600 text-white font-semibold rounded-xl shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40 transition-all hover:scale-105 text-sm"
          >
            <Zap className="w-4 h-4" />
            {t('استخدم أداة', 'Use a Tool')}
            <ArrowIcon className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {[
            {
              icon: Zap,
              label: t('الرصيد المتبقي', 'Remaining Credits'),
              value: profile?.credits ?? 0,
              color: '#f97316',
              sub: t('من 50 رصيد', 'of 50 credits'),
            },
            {
              icon: Activity,
              label: t('المهام المنجزة', 'Tasks Completed'),
              value: usage.length,
              color: '#10b981',
              sub: t('هذا الشهر', 'this month'),
            },
            {
              icon: BarChart2,
              label: t('الرصيد المستخدم', 'Credits Used'),
              value: totalCreditsUsed,
              color: '#3b82f6',
              sub: t('إجمالي', 'total'),
            },
            {
              icon: Award,
              label: t('الخطة الحالية', 'Current Plan'),
              value: profile?.plan || 'free',
              color: planColor,
              sub: t('الاشتراك النشط', 'active subscription'),
              isText: true,
            },
          ].map((stat, i) => (
            <div key={i} className="bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 rounded-2xl p-5">
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${stat.color}20` }}>
                  <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
                </div>
                <TrendingUp className="w-3.5 h-3.5 text-green-400" />
              </div>
              <div className="text-2xl font-black text-white mb-1 capitalize">{stat.value}</div>
              <div className="text-sm text-gray-400">{stat.label}</div>
              <div className="text-xs text-gray-600 mt-1">{stat.sub}</div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Quick Actions */}
          <div className="lg:col-span-2 bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-white font-bold text-lg">{t('الأدوات السريعة', 'Quick Tools')}</h2>
              <button onClick={() => onNavigate('tools')} className="text-orange-400 hover:text-orange-300 text-sm flex items-center gap-1">
                {t('الكل', 'All')} <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {quickActions.map(({ tool, icon: Icon }) => (
                <button
                  key={tool.id}
                  onClick={() => onNavigate('tool', tool.id)}
                  className="flex items-center gap-3 p-3 bg-white/3 hover:bg-white/8 border border-white/5 hover:border-white/10 rounded-xl transition-all group text-start"
                >
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: `${tool.color}20` }}
                  >
                    <Icon className="w-4 h-4" style={{ color: tool.color }} />
                  </div>
                  <span className="text-gray-300 text-sm font-medium group-hover:text-white transition-colors line-clamp-1">
                    {t(tool.nameAr, tool.nameEn)}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Profile Card */}
            <div className="bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 rounded-2xl p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-orange-600 rounded-xl flex items-center justify-center text-xl font-bold text-white">
                  {profile?.full_name?.charAt(0) || user.email?.charAt(0)?.toUpperCase()}
                </div>
                <div>
                  <p className="text-white font-semibold">{profile?.full_name || t('المستخدم', 'User')}</p>
                  <p className="text-gray-400 text-xs truncate max-w-[140px]">{user.email}</p>
                </div>
              </div>
              <div className="space-y-2">
                {[
                  { icon: User, label: t('الملف الشخصي', 'Profile'), page: 'account' },
                  { icon: Key, label: t('مفاتيح API', 'API Keys'), page: 'api-keys' },
                  { icon: Bell, label: t('الإشعارات', 'Notifications'), page: 'notifications' },
                  { icon: Settings, label: t('الإعدادات', 'Settings'), page: 'settings' },
                ].map(item => (
                  <button
                    key={item.page}
                    onClick={() => onNavigate(item.page)}
                    className="flex items-center justify-between w-full px-3 py-2 rounded-xl text-gray-400 hover:text-white hover:bg-white/5 transition-all group text-sm"
                  >
                    <div className="flex items-center gap-2.5">
                      <item.icon className="w-3.5 h-3.5" />
                      {item.label}
                    </div>
                    <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                ))}
              </div>
            </div>

            {/* Upgrade Card */}
            {profile?.plan === 'free' && (
              <div className="bg-gradient-to-br from-orange-500/15 to-orange-600/5 border border-orange-500/20 rounded-2xl p-5">
                <Brain className="w-8 h-8 text-orange-400 mb-3" />
                <h3 className="text-white font-semibold mb-2">{t('ترقية الخطة', 'Upgrade Plan')}</h3>
                <p className="text-gray-400 text-xs mb-4">
                  {t('احصل على 1000 رصيد وجميع الأدوات مع الخطة الاحترافية', 'Get 1000 credits and all tools with the Professional plan')}
                </p>
                <button
                  onClick={() => onNavigate('pricing')}
                  className="w-full py-2 bg-gradient-to-r from-orange-500 to-orange-600 text-white text-sm font-semibold rounded-xl flex items-center justify-center gap-2 hover:from-orange-600 hover:to-orange-700 transition-all"
                >
                  <Zap className="w-3.5 h-3.5" />
                  {t('ترقية الآن', 'Upgrade Now')}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="mt-6 bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-white font-bold text-lg flex items-center gap-2">
              <Clock className="w-4 h-4 text-orange-400" />
              {t('النشاط الأخير', 'Recent Activity')}
            </h2>
          </div>
          {loading ? (
            <div className="flex justify-center py-10">
              <div className="w-6 h-6 border-2 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
            </div>
          ) : usage.length === 0 ? (
            <div className="text-center py-10 text-gray-500">
              <Activity className="w-8 h-8 mx-auto mb-3 opacity-30" />
              <p className="text-sm">{t('لا يوجد نشاط حتى الآن', 'No activity yet')}</p>
              <button onClick={() => onNavigate('tools')} className="mt-3 text-orange-400 text-sm hover:text-orange-300">
                {t('جرب أداة الآن', 'Try a tool now')}
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              {usage.map(item => (
                <div key={item.id} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-orange-500/10 rounded-xl flex items-center justify-center">
                      <Zap className="w-3.5 h-3.5 text-orange-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{item.tool_name}</p>
                      <p className="text-gray-500 text-xs">{new Date(item.created_at).toLocaleDateString('ar-SA')}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-gray-400">{item.credits_used} {t('رصيد', 'credits')}</span>
                    <span className={`px-2 py-0.5 rounded-full text-xs ${
                      item.status === 'success' ? 'bg-green-500/15 text-green-400' : 'bg-red-500/15 text-red-400'
                    }`}>
                      {item.status === 'success' ? t('ناجح', 'Success') : t('فشل', 'Failed')}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
