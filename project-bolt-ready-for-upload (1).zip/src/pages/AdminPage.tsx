import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { supabase } from '../lib/supabase';
import { Users, Activity, Mail, TrendingUp, BarChart2, Eye, CheckCircle, Clock } from 'lucide-react';

interface AdminPageProps {
  onNavigate: (page: string) => void;
}

interface Lead {
  id: string;
  name: string;
  email: string;
  company: string;
  message: string;
  status: string;
  created_at: string;
}

export default function AdminPage({ onNavigate }: AdminPageProps) {
  const { profile } = useAuth();
  const { t } = useApp();
  const [leads, setLeads] = useState<Lead[]>([]);
  const [stats, setStats] = useState({ users: 0, totalUsage: 0, leadsCount: 0 });
  const [loading, setLoading] = useState(true);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);

  useEffect(() => {
    if (!profile?.is_admin) return;
    const fetchData = async () => {
      const [leadsRes, usageRes] = await Promise.all([
        supabase.from('leads').select('*').order('created_at', { ascending: false }),
        supabase.from('tool_usage').select('id', { count: 'exact' }),
      ]);
      setLeads(leadsRes.data || []);
      setStats({
        users: 0,
        totalUsage: usageRes.count || 0,
        leadsCount: leadsRes.data?.length || 0,
      });
      setLoading(false);
    };
    fetchData();
  }, [profile]);

  if (!profile?.is_admin) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-400 mb-4">{t('غير مصرح لك بالوصول', 'Access denied')}</p>
          <button onClick={() => onNavigate('home')} className="text-orange-400">{t('العودة', 'Go back')}</button>
        </div>
      </div>
    );
  }

  const handleUpdateLeadStatus = async (id: string, status: string) => {
    await supabase.from('leads').update({ status }).eq('id', id);
    setLeads(prev => prev.map(l => l.id === id ? { ...l, status } : l));
  };

  const statusColors: Record<string, string> = {
    new: 'bg-blue-500/15 text-blue-400',
    contacted: 'bg-yellow-500/15 text-yellow-400',
    converted: 'bg-green-500/15 text-green-400',
    closed: 'bg-gray-500/15 text-gray-400',
  };

  return (
    <div className="min-h-screen pt-20 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-black text-white mb-8">{t('لوحة الإدارة', 'Admin Panel')}</h1>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 mb-8">
          {[
            { icon: Users, label: t('المستخدمون', 'Users'), value: stats.users, color: '#3b82f6' },
            { icon: Activity, label: t('إجمالي الاستخدام', 'Total Usage'), value: stats.totalUsage, color: '#10b981' },
            { icon: Mail, label: t('العملاء المحتملون', 'Leads'), value: stats.leadsCount, color: '#f97316' },
          ].map((stat, i) => (
            <div key={i} className="bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 rounded-2xl p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-9 h-9 rounded-xl flex items-center justify-center" style={{ background: `${stat.color}20` }}>
                  <stat.icon className="w-4 h-4" style={{ color: stat.color }} />
                </div>
                <span className="text-gray-400 text-sm">{stat.label}</span>
              </div>
              <div className="text-3xl font-black text-white">{loading ? '...' : stat.value}</div>
            </div>
          ))}
        </div>

        {/* Leads Table */}
        <div className="bg-gradient-to-b from-white/5 to-white/[0.02] border border-white/8 rounded-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-white/8 flex items-center justify-between">
            <h2 className="text-white font-bold text-lg flex items-center gap-2">
              <Mail className="w-4 h-4 text-orange-400" />
              {t('العملاء المحتملون', 'Leads')}
            </h2>
            <span className="text-sm text-gray-400">{leads.length} {t('عميل', 'leads')}</span>
          </div>

          {loading ? (
            <div className="flex justify-center py-12">
              <div className="w-6 h-6 border-2 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
            </div>
          ) : leads.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Mail className="w-8 h-8 mx-auto mb-3 opacity-30" />
              <p className="text-sm">{t('لا يوجد عملاء محتملون حتى الآن', 'No leads yet')}</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-white/5">
                    {[
                      t('الاسم', 'Name'),
                      t('البريد', 'Email'),
                      t('الشركة', 'Company'),
                      t('الحالة', 'Status'),
                      t('التاريخ', 'Date'),
                      t('الإجراءات', 'Actions'),
                    ].map((h, i) => (
                      <th key={i} className="px-4 py-3 text-start text-xs font-medium text-gray-500 uppercase tracking-wide">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {leads.map(lead => (
                    <tr key={lead.id} className="border-b border-white/5 hover:bg-white/2 transition-colors">
                      <td className="px-4 py-3 text-white text-sm font-medium">{lead.name}</td>
                      <td className="px-4 py-3 text-gray-400 text-sm">{lead.email}</td>
                      <td className="px-4 py-3 text-gray-400 text-sm">{lead.company || '-'}</td>
                      <td className="px-4 py-3">
                        <select
                          value={lead.status}
                          onChange={e => handleUpdateLeadStatus(lead.id, e.target.value)}
                          className={`px-2.5 py-1 rounded-full text-xs font-medium cursor-pointer border-0 outline-none ${statusColors[lead.status] || statusColors.new}`}
                          style={{ background: 'transparent' }}
                        >
                          <option value="new" className="bg-[#0d1b4b]">{t('جديد', 'New')}</option>
                          <option value="contacted" className="bg-[#0d1b4b]">{t('تم التواصل', 'Contacted')}</option>
                          <option value="converted" className="bg-[#0d1b4b]">{t('محوّل', 'Converted')}</option>
                          <option value="closed" className="bg-[#0d1b4b]">{t('مغلق', 'Closed')}</option>
                        </select>
                      </td>
                      <td className="px-4 py-3 text-gray-500 text-xs">{new Date(lead.created_at).toLocaleDateString('ar-SA')}</td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => setSelectedLead(lead)}
                          className="p-1.5 text-gray-500 hover:text-orange-400 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Lead Detail Modal */}
        {selectedLead && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedLead(null)}>
            <div className="bg-[#0d1b4b] border border-white/15 rounded-2xl p-6 max-w-md w-full" onClick={e => e.stopPropagation()}>
              <h3 className="text-white font-bold text-lg mb-4">{t('تفاصيل العميل', 'Lead Details')}</h3>
              <div className="space-y-3">
                {[
                  { label: t('الاسم', 'Name'), value: selectedLead.name },
                  { label: t('البريد', 'Email'), value: selectedLead.email },
                  { label: t('الشركة', 'Company'), value: selectedLead.company || '-' },
                  { label: t('الرسالة', 'Message'), value: selectedLead.message || '-' },
                ].map(({ label, value }, i) => (
                  <div key={i}>
                    <p className="text-gray-500 text-xs mb-0.5">{label}</p>
                    <p className="text-white text-sm">{value}</p>
                  </div>
                ))}
              </div>
              <button onClick={() => setSelectedLead(null)} className="mt-6 w-full py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 text-gray-300 rounded-xl text-sm transition-all">
                {t('إغلاق', 'Close')}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
