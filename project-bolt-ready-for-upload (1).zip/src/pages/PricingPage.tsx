import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { useAuth } from '../context/AuthContext';
import { PLANS } from '../data/tools';
import { CheckCircle, Zap, Crown, Building2, ArrowRight, ArrowLeft } from 'lucide-react';

interface PricingPageProps {
  onNavigate: (page: string) => void;
}

export default function PricingPage({ onNavigate }: PricingPageProps) {
  const { t, lang } = useApp();
  const { user } = useAuth();
  const [billing, setBilling] = useState<'monthly' | 'yearly'>('monthly');
  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  const planIcons = [Zap, Crown, Building2];

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <div className="py-20 text-center relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-1/2 start-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-orange-500/8 rounded-full filter blur-3xl" />
        </div>
        <div className="relative max-w-3xl mx-auto px-4">
          <h1 className="text-5xl font-black text-white mb-4">{t('الأسعار', 'Pricing')}</h1>
          <p className="text-gray-400 text-lg mb-8">
            {t('اختر الخطة المناسبة لاحتياجاتك', 'Choose the plan that suits your needs')}
          </p>

          {/* Billing Toggle */}
          <div className="inline-flex items-center bg-white/5 border border-white/10 rounded-2xl p-1">
            {(['monthly', 'yearly'] as const).map(b => (
              <button
                key={b}
                onClick={() => setBilling(b)}
                className={`px-6 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                  billing === b
                    ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/25'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                {b === 'monthly' ? t('شهري', 'Monthly') : t('سنوي', 'Yearly')}
                {b === 'yearly' && (
                  <span className={`ms-1.5 px-1.5 py-0.5 rounded-full text-xs ${
                    billing === 'yearly' ? 'bg-white/20' : 'bg-green-500/20 text-green-400'
                  }`}>
                    -17%
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Plans */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {PLANS.map((plan, i) => {
            const PlanIcon = planIcons[i];
            const price = billing === 'monthly' ? plan.priceMonthly : Math.round(plan.priceYearly / 12);
            return (
              <div
                key={plan.id}
                className={`relative rounded-3xl overflow-hidden transition-all hover:-translate-y-1 ${
                  plan.popular
                    ? 'border-2 border-orange-500 shadow-2xl shadow-orange-500/20'
                    : 'border border-white/10'
                }`}
              >
                {plan.popular && (
                  <div className="absolute top-0 inset-x-0 py-1.5 bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs font-bold text-center">
                    {t('الأكثر شعبية', 'Most Popular')}
                  </div>
                )}
                <div className={`bg-gradient-to-b from-white/5 to-white/[0.02] p-7 ${plan.popular ? 'pt-10' : ''}`}>
                  {/* Plan Icon */}
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-5 bg-gradient-to-br ${plan.color} bg-opacity-20`}>
                    <PlanIcon className="w-5.5 h-5.5 text-white" />
                  </div>

                  {/* Plan Name */}
                  <h2 className="text-xl font-bold text-white mb-1">{t(plan.nameAr, plan.nameEn)}</h2>
                  <p className="text-gray-400 text-sm mb-6">{plan.credits.toLocaleString()} {t('رصيد شهرياً', 'credits/month')}</p>

                  {/* Price */}
                  <div className="mb-7">
                    {plan.priceMonthly === 0 ? (
                      <div className="text-4xl font-black text-white">{t('مجاني', 'Free')}</div>
                    ) : (
                      <div className="flex items-end gap-2">
                        <span className="text-4xl font-black text-white">{price}</span>
                        <span className="text-gray-400 mb-1">{t('ريال/شهر', 'SAR/mo')}</span>
                      </div>
                    )}
                    {billing === 'yearly' && plan.priceYearly > 0 && (
                      <p className="text-green-400 text-xs mt-1">
                        {t(`يُدفع ${plan.priceYearly} ريال سنوياً`, `Billed ${plan.priceYearly} SAR/year`)}
                      </p>
                    )}
                  </div>

                  {/* CTA */}
                  <button
                    onClick={() => user ? onNavigate('dashboard') : onNavigate('register')}
                    className={`w-full py-3 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all mb-7 ${
                      plan.popular
                        ? 'bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white shadow-lg shadow-orange-500/25 hover:shadow-orange-500/40'
                        : 'bg-white/5 hover:bg-white/10 border border-white/10 text-white'
                    }`}
                  >
                    {plan.priceMonthly === 0 ? t('ابدأ مجاناً', 'Start Free') : t('اشترك الآن', 'Subscribe Now')}
                    <ArrowIcon className="w-3.5 h-3.5" />
                  </button>

                  {/* Features */}
                  <ul className="space-y-3">
                    {plan.features.map((feature, j) => (
                      <li key={j} className="flex items-start gap-2.5">
                        <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0 mt-0.5" />
                        <span className="text-gray-300 text-sm">{t(feature.ar, feature.en)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>

        {/* Enterprise CTA */}
        <div className="mt-12 p-8 bg-gradient-to-r from-[#0d1b4b] to-[#111c4a] border border-white/10 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-xl font-bold text-white mb-2">{t('هل تحتاج إلى خطة مخصصة؟', 'Need a Custom Plan?')}</h3>
            <p className="text-gray-400">{t('تواصل معنا للحصول على عرض سعر مخصص لشركتك', 'Contact us for a custom quote for your company')}</p>
          </div>
          <button
            onClick={() => onNavigate('contact')}
            className="flex items-center gap-2 px-8 py-3 bg-white text-[#060f33] font-bold rounded-2xl hover:bg-gray-100 transition-all whitespace-nowrap"
          >
            {t('تواصل معنا', 'Contact Us')}
            <ArrowIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
