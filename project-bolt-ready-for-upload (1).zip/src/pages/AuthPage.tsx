import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useApp } from '../context/AppContext';
import { Brain, Eye, EyeOff, Loader2, CheckCircle, ArrowLeft, ArrowRight } from 'lucide-react';

interface AuthPageProps {
  mode: 'login' | 'register';
  onNavigate: (page: string) => void;
}

export default function AuthPage({ mode, onNavigate }: AuthPageProps) {
  const { signIn, signUp } = useAuth();
  const { t, lang } = useApp();
  const [form, setForm] = useState({ email: '', password: '', fullName: '', confirmPassword: '' });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const ArrowIcon = lang === 'ar' ? ArrowLeft : ArrowRight;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    if (mode === 'register' && form.password !== form.confirmPassword) {
      setError(t('كلمات المرور غير متطابقة', 'Passwords do not match'));
      setLoading(false);
      return;
    }
    if (form.password.length < 6) {
      setError(t('كلمة المرور يجب أن تكون 6 أحرف على الأقل', 'Password must be at least 6 characters'));
      setLoading(false);
      return;
    }

    try {
      if (mode === 'login') {
        const { error } = await signIn(form.email, form.password);
        if (error) throw error;
        onNavigate('dashboard');
      } else {
        const { error } = await signUp(form.email, form.password, form.fullName);
        if (error) throw error;
        setSuccess(true);
        setTimeout(() => onNavigate('dashboard'), 1500);
      }
    } catch (err: unknown) {
      const errMsg = err instanceof Error ? err.message : '';
      if (errMsg.includes('Invalid login credentials')) {
        setError(t('بيانات الدخول غير صحيحة', 'Invalid credentials'));
      } else if (errMsg.includes('already registered')) {
        setError(t('البريد الإلكتروني مسجل مسبقاً', 'Email already registered'));
      } else {
        setError(errMsg || t('حدث خطأ', 'An error occurred'));
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Panel */}
      <div className="hidden lg:flex flex-col justify-between w-1/2 bg-gradient-to-br from-[#0d1b4b] to-[#060f33] p-12 relative overflow-hidden">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.04) 1px, transparent 0)',
          backgroundSize: '40px 40px',
        }} />
        <div className="absolute top-1/3 start-1/3 w-64 h-64 bg-orange-500/10 rounded-full filter blur-3xl" />

        <div className="relative">
          <button onClick={() => onNavigate('home')} className="flex items-center gap-2.5">
            <div className="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold text-white">AI Hub <span className="text-orange-400">Arabia</span></span>
          </button>
        </div>

        <div className="relative">
          <h2 className="text-4xl font-black text-white mb-4">
            {t('ابدأ رحلتك مع الذكاء الاصطناعي', 'Start Your AI Journey')}
          </h2>
          <p className="text-gray-400 mb-8 leading-relaxed">
            {t(
              'انضم لأكثر من 10,000 شركة ورائد أعمال يستخدمون أدواتنا لتسريع أعمالهم.',
              'Join over 10,000 companies and entrepreneurs using our tools to accelerate their business.'
            )}
          </p>
          <div className="space-y-3">
            {[
              t('50 رصيد مجاناً عند التسجيل', '50 free credits on registration'),
              t('وصول فوري لجميع الأدوات', 'Instant access to all tools'),
              t('لا يوجد بطاقة ائتمان مطلوبة', 'No credit card required'),
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-3">
                <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                <span className="text-gray-300 text-sm">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative text-gray-600 text-xs">
          {t('© 2024 AI Hub Arabia', '© 2024 AI Hub Arabia')}
        </div>
      </div>

      {/* Right Panel - Form */}
      <div className="flex-1 flex items-center justify-center p-6 bg-[#060f33]">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="flex lg:hidden items-center gap-2.5 mb-8">
            <div className="w-9 h-9 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="text-lg font-bold text-white">AI Hub <span className="text-orange-400">Arabia</span></span>
          </div>

          <div className="mb-8">
            <h1 className="text-3xl font-black text-white mb-2">
              {mode === 'login' ? t('مرحباً بعودتك', 'Welcome Back') : t('إنشاء حساب جديد', 'Create New Account')}
            </h1>
            <p className="text-gray-400">
              {mode === 'login'
                ? t('أدخل بياناتك للدخول لحسابك', 'Enter your credentials to access your account')
                : t('أنشئ حسابك المجاني الآن', 'Create your free account now')
              }
            </p>
          </div>

          {success ? (
            <div className="text-center py-12">
              <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-2">{t('تم إنشاء الحساب!', 'Account Created!')}</h3>
              <p className="text-gray-400">{t('جاري تحويلك للوحة التحكم...', 'Redirecting to dashboard...')}</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <div>
                  <label className="text-sm font-medium text-gray-300 mb-1.5 block">{t('الاسم الكامل', 'Full Name')}</label>
                  <input
                    type="text"
                    required
                    placeholder={t('أدخل اسمك الكامل', 'Enter your full name')}
                    value={form.fullName}
                    onChange={e => setForm(p => ({ ...p, fullName: e.target.value }))}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  />
                </div>
              )}

              <div>
                <label className="text-sm font-medium text-gray-300 mb-1.5 block">{t('البريد الإلكتروني', 'Email')}</label>
                <input
                  type="email"
                  required
                  placeholder="example@company.com"
                  value={form.email}
                  onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                />
              </div>

              <div>
                <label className="text-sm font-medium text-gray-300 mb-1.5 block">{t('كلمة المرور', 'Password')}</label>
                <div className="relative">
                  <input
                    type={showPass ? 'text' : 'password'}
                    required
                    placeholder="••••••••"
                    value={form.password}
                    onChange={e => setForm(p => ({ ...p, password: e.target.value }))}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 pe-11 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute end-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white"
                  >
                    {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {mode === 'register' && (
                <div>
                  <label className="text-sm font-medium text-gray-300 mb-1.5 block">{t('تأكيد كلمة المرور', 'Confirm Password')}</label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={form.confirmPassword}
                    onChange={e => setForm(p => ({ ...p, confirmPassword: e.target.value }))}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-gray-500 text-sm focus:outline-none focus:border-orange-500/50 transition-colors"
                  />
                </div>
              )}

              {error && (
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-sm">
                  {error}
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 disabled:opacity-60 text-white font-semibold rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowIcon className="w-4 h-4" />}
                {loading
                  ? t('جاري المعالجة...', 'Processing...')
                  : mode === 'login'
                    ? t('تسجيل الدخول', 'Sign In')
                    : t('إنشاء الحساب', 'Create Account')
                }
              </button>

              <div className="text-center text-sm text-gray-400">
                {mode === 'login' ? (
                  <>
                    {t('ليس لديك حساب؟', 'Don\'t have an account?')}{' '}
                    <button type="button" onClick={() => onNavigate('register')} className="text-orange-400 hover:text-orange-300 font-medium">
                      {t('سجل الآن', 'Sign up')}
                    </button>
                  </>
                ) : (
                  <>
                    {t('لديك حساب بالفعل؟', 'Already have an account?')}{' '}
                    <button type="button" onClick={() => onNavigate('login')} className="text-orange-400 hover:text-orange-300 font-medium">
                      {t('سجل دخول', 'Sign in')}
                    </button>
                  </>
                )}
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
